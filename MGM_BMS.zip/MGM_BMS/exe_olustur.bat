@echo off
REM Tek dosyalik MGM_BMS.exe olusturur (dist klasorune)
cd /d "%~dp0"
python -m pip install -q -r requirements.txt pyinstaller
python -m PyInstaller --noconfirm --onefile --windowed --name MGM_BMS ^
  --add-data "ui;ui" --collect-submodules bleak --collect-data webview mgm_bms.py
echo.
echo Hazir: dist\MGM_BMS.exe
pause
